package np.nepaltelecom.telemetry

import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkRequest
import androidx.work.workDataOf
import np.nepaltelecom.telemetry.collector.DriveShare
import np.nepaltelecom.telemetry.collector.Environment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import np.nepaltelecom.telemetry.collector.CallListener
import np.nepaltelecom.telemetry.collector.CellSampleCollector
import np.nepaltelecom.telemetry.storage.CallQueue
import np.nepaltelecom.telemetry.storage.SpeedResultQueue
import np.nepaltelecom.telemetry.upload.CallUploadWorker
import np.nepaltelecom.telemetry.upload.SpeedResultUploadWorker
import np.nepaltelecom.telemetry.collector.DriveHistoryStore
import np.nepaltelecom.telemetry.collector.DriveTestService
import np.nepaltelecom.telemetry.collector.RouteTrail
import np.nepaltelecom.telemetry.model.CellReading
import np.nepaltelecom.telemetry.model.DriveSession
import np.nepaltelecom.telemetry.collector.HandoverListener
import np.nepaltelecom.telemetry.collector.SamplingWorker
import np.nepaltelecom.telemetry.collector.ShareExpiryReceiver
import np.nepaltelecom.telemetry.collector.ShareWindow
import android.app.AlarmManager
import android.app.PendingIntent
import np.nepaltelecom.telemetry.storage.DeviceIdentity
import np.nepaltelecom.telemetry.model.Sample
import np.nepaltelecom.telemetry.storage.SampleQueue
import np.nepaltelecom.telemetry.upload.DriveTestConsentApi
import np.nepaltelecom.telemetry.upload.DriveTestConsentWorker
import np.nepaltelecom.telemetry.upload.RescueEnrollWorker
import np.nepaltelecom.telemetry.upload.UploadWorker
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

/**
 * Public entry point -- this is the entire surface the host app needs to
 * call. No UI anywhere in this module; the host app's own opt-in screen and
 * any "your signal quality" view are expected to call these methods and
 * render [getStatus] themselves.
 *
 * INTEGRATION NOTE, easy to get wrong: call [init] from the host app's
 * `Application.onCreate()`, not from an Activity/Fragment. WorkManager can
 * (and, on a pilot running for weeks, will) execute [SamplingWorker] and
 * [UploadWorker] after the app's process has been killed and relaunched
 * fresh by the OS -- if [init] only ever ran inside an Activity that never
 * got reopened, [internalConfig] is null when that work executes and it
 * quietly no-ops. Application.onCreate() runs on every process start,
 * including OS-triggered background relaunches, which is why it belongs
 * there.
 */
object NetTelemetry {

    private lateinit var appContext: Context
    private var handoverListener: HandoverListener? = null
    private var callListener: CallListener? = null
    private val scope = CoroutineScope(Dispatchers.Default)
    private val lastHandoverSampleAtMs = AtomicLong(0)
    private val lastOnDemandSampleAtMs = AtomicLong(0)

    private const val PUSH_PREFS = "netplanning_push"
    private const val KEY_PUSH_TOKEN = "fcm_token"
    private const val MIN_ON_DEMAND_INTERVAL_MS = 120_000L
    private const val ON_DEMAND_TIMEOUT_MS = 15_000L

    private const val SAMPLING_WORK_NAME = "netplanning_telemetry_sampling"
    private const val UPLOAD_WORK_NAME = "netplanning_telemetry_upload"
    private const val RESCUE_ENROLL_WORK_NAME = "netplanning_telemetry_rescue_enroll"
    private const val DRIVE_TEST_CONSENT_WORK_NAME = "netplanning_telemetry_dt_consent"
    private const val CALL_UPLOAD_WORK_NAME = "netplanning_call_upload"
    private const val SPEED_UPLOAD_WORK_NAME = "netplanning_speed_upload"

    /**
     * Whether this phone can run the SDK (2026-10-16). The SDK installs on
     * Android 7.0 so an app that supports it can include it, but the signal
     * readings need Android 8.0. Below that every feature is off: [init]
     * schedules nothing, and each call that would collect or send does
     * nothing (reads pass back null or an empty list). A host app should hide
     * its telemetry screens when this is false.
     */
    fun isSupported(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O

    fun init(context: Context, config: TelemetryConfig) {
        appContext = context.applicationContext
        internalConfig = config
        np.nepaltelecom.telemetry.device.DeviceApi.configure(config.deviceApiUrl, config.endpointUrl)
        if (!isSupported()) return
        val identity = DeviceIdentity(appContext)
        // First-run seeding (2026-09-02): only when this device has NEVER
        // stored an opt-in choice, and only when the host app opted into
        // an opt-out model via TelemetryConfig.defaultOptIn -- see that
        // field's doc comment. hasExplicitOptInState guards this so it can
        // never fire again after the very first init() on a device, even
        // if a later app update changes defaultOptIn: a subscriber's own
        // later optIn()/optOut() call always wins from that point on.
        if (!identity.hasExplicitOptInState && config.defaultOptIn) {
            identity.optedIn = true
        }
        // Rescheduling on every init() is deliberately idempotent (KEEP policy
        // below) -- calling init() again with the same config on every app
        // launch, as the integration guide recommends, does not reset or
        // duplicate already-scheduled work.
        expireShareIfDue()
        // A drive that switched sharing on for itself, with no drive running any
        // more: the process died mid-drive. Close it the way Stop would have.
        if (DriveShare.autoOptIn(appContext) && DriveTestService.activeSessionId == null) onDriveStopped()
        if (DriveShare.drainPending(appContext)) enqueueDrain()
        if (identity.optedIn) {
            scheduleBackgroundWork()
            startHandoverListener()
            startCallListener()
        }
    }

    fun optIn() {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before optIn()" }
        if (!isSupported()) return
        DeviceIdentity(appContext).optedIn = true
        scheduleBackgroundWork()
        startHandoverListener()
        startCallListener()
        syncPushToken(register = true)
    }

    fun optOut(wipeQueuedData: Boolean = true) {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before optOut()" }
        DeviceIdentity(appContext).optedIn = false
        WorkManager.getInstance(appContext).cancelUniqueWork(SAMPLING_WORK_NAME)
        WorkManager.getInstance(appContext).cancelUniqueWork(UPLOAD_WORK_NAME)
        handoverListener?.stop()
        handoverListener = null
        callListener?.stop()
        callListener = null
        if (wipeQueuedData) {
            SampleQueue(appContext).clear()
            CallQueue(appContext).clear()
            SpeedResultQueue(appContext).clear()
            DriveShare.setDrainPending(appContext, false)
        }
        syncPushToken(register = false)
    }

    /**
     * Sends what is already queued even though sharing is now off (2026-10-12).
     * Before this, switching sharing off at the end of a window or a drive left
     * its last readings, and its "ended" marker, on the phone: the uploader does
     * nothing while sharing is off. Retries on its own until the server answers.
     */
    private fun enqueueDrain() {
        DriveShare.setDrainPending(appContext, true)
        val work = OneTimeWorkRequestBuilder<UploadWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, java.util.concurrent.TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(appContext).enqueueUniqueWork(DRAIN_WORK_NAME, ExistingWorkPolicy.REPLACE, work)
    }

    /**
     * Called when a drive test ends. A drive that switched sharing on for itself
     * switches it off again, and what it recorded is sent, now or when the server
     * can next be reached. A drive started while the user was already sharing just
     * uploads; sharing stays as the user set it.
     */
    internal fun onDriveStopped() {
        if (!::appContext.isInitialized) return
        if (DriveShare.autoOptIn(appContext)) {
            DriveShare.setAutoOptIn(appContext, false)
            enqueueDrain()
            optOut(wipeQueuedData = false)
        } else {
            uploadNow()
        }
    }

    /** Length of one share window when the caller doesn't choose one (2026-10-07). */
    const val DEFAULT_SHARE_CAP_MINUTES = 60

    private const val DRAIN_WORK_NAME = "netplanning_drain_upload"

    /**
     * Starts sharing for a time-limited window (2026-10-07). The window's samples
     * are tagged with one session ID, so the server shows them as one session.
     * The window ends on its own at the cap, and the user can stop it earlier.
     * Returns when the window ends, in epoch ms.
     */
    fun startShare(capMinutes: Int = DEFAULT_SHARE_CAP_MINUTES): Long {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before startShare()" }
        if (!isSupported()) return 0L
        val expiresAt = System.currentTimeMillis() + capMinutes * 60_000L
        ShareWindow.start(appContext, java.util.UUID.randomUUID().toString(), expiresAt)
        optIn()
        scheduleShareExpiry(expiresAt)
        scope.launch { markShare("drive_start", ShareWindow.storedSessionId(appContext)) }
        return expiresAt
    }

    /**
     * Ends the share window now (2026-10-07). Sends the end marker, uploads what
     * is queued while still opted in, then opts out. Queued samples are kept.
     */
    fun stopShare() {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before stopShare()" }
        cancelShareExpiry()
        Environment.setManual(appContext, null)  // a choice holds only for its session (2026-10-26)
        scope.launch {
            if (isOptedIn()) {
                // The stored ID survives the window's end, so an expiry still closes the session.
                markShare("drive_stop", ShareWindow.storedSessionId(appContext))
                // Not uploadNow(): sharing is switched off two lines below, and the
                // uploader would then leave this window's last readings behind.
                enqueueDrain()
            }
            ShareWindow.clear(appContext)
            optOut(wipeQueuedData = false)
        }
    }

    /** Called by the expiry alarm. Ends the window if it is still open. */
    fun onShareExpiryAlarm() {
        if (!::appContext.isInitialized) return
        if (DeviceIdentity(appContext).optedIn) stopShare()
    }

    /**
     * Run on startup. An opt-in with no open window is one from before the cap
     * existed, or one whose time has passed, so it is ended here (2026-10-07).
     */
    fun expireShareIfDue() {
        if (!::appContext.isInitialized) return
        if (DeviceIdentity(appContext).optedIn && ShareWindow.currentSessionId(appContext) == null) {
            stopShare()
        }
    }

    /** When the current share window ends, or null when not sharing. */
    fun shareExpiresAtMs(): Long? =
        if (ShareWindow.currentSessionId(appContext) != null) ShareWindow.expiresAtMs(appContext) else null

    private suspend fun markShare(trigger: String, sessionId: String?) {
        val sample = CellSampleCollector(appContext, DeviceIdentity(appContext))
            .collect(triggerReason = trigger, driveSessionId = sessionId)
        sample?.let { SampleQueue(appContext).append(it) }
    }

    private fun shareExpiryIntent(): PendingIntent = PendingIntent.getBroadcast(
        appContext, 0,
        android.content.Intent(appContext, ShareExpiryReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    private fun scheduleShareExpiry(atMs: Long) {
        appContext.getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMs, shareExpiryIntent())
    }

    private fun cancelShareExpiry() {
        appContext.getSystemService(AlarmManager::class.java).cancel(shareExpiryIntent())
    }

    fun isOptedIn(): Boolean {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before isOptedIn()" }
        return isSupported() && DeviceIdentity(appContext).optedIn
    }

    fun getStatus(): TelemetryStatus {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before getStatus()" }
        val identity = DeviceIdentity(appContext)
        val queue = SampleQueue(appContext)
        return TelemetryStatus(
            optedIn = identity.optedIn,
            queuedSampleCount = queue.size(),
            lastSampleAtMs = queue.lastSampleAtMs(),
            lastUploadAttemptAtMs = null, // left for the host app to track via a WorkManager observer if it wants finer detail than this
        )
    }

    /**
     * Optional: lets the host app trigger an immediate, foreground sample --
     * e.g. from its own "check my signal now" button. Not required for the
     * pilot's automatic collection, which runs on its own schedule.
     */
    fun sampleNow() {
        if (!isOptedIn()) return
        scope.launch {
            val identity = DeviceIdentity(appContext)
            val sample = CellSampleCollector(appContext, identity).collect(triggerReason = "manual")
            sample?.let { SampleQueue(appContext).append(it) }
        }
    }

    /**
     * Reads this device's live cell, signal and location state right now and
     * passes it to [onResult] -- for a host app's own "show my live readings"
     * screen. Nothing is queued or uploaded; this is a local read only.
     *
     * [onResult] runs on a background thread. It receives null when location
     * permission is missing or no cell/location state is available. Works
     * without opt-in, since it sends nothing anywhere.
     */
    fun readLiveSample(onResult: (Sample?) -> Unit) {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before readLiveSample()" }
        if (!isSupported()) return onResult(null)
        scope.launch {
            val sample = CellSampleCollector(appContext, DeviceIdentity(appContext)).collectLive(triggerReason = "manual")
            onResult(sample)
        }
    }

    /**
     * Reads the current cell and signal state with no location fix, so a
     * screen can refresh every few seconds without waiting on GPS. Needs only
     * location permission, not opt-in. Passes null when permission is missing.
     * Nothing is queued or uploaded.
     */
    fun readLiveCell(onResult: (Sample?) -> Unit) {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before readLiveCell()" }
        if (!isSupported()) return onResult(null)
        scope.launch {
            onResult(
                CellSampleCollector(appContext, DeviceIdentity(appContext))
                    .sampleFrom(null, "manual", requireOptIn = false),
            )
        }
    }

    /**
     * Reads every cell the modem reports right now, serving cell and
     * neighbours alike. Passes an empty list when location permission is
     * missing. Local read only, with nothing queued or uploaded.
     */
    fun readCellsNow(onResult: (List<CellReading>) -> Unit) {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before readCellsNow()" }
        if (!isSupported()) return onResult(emptyList())
        scope.launch {
            onResult(CellSampleCollector(appContext, DeviceIdentity(appContext)).readAllCells())
        }
    }

    /** Fixes accepted by the current drive test, in order. Lives in memory only. */
    fun routeTrail(): List<RouteTrail.Point> = RouteTrail.points()

    /** Clears the on-phone route trail. Does not touch anything already queued for upload. */
    fun clearRouteTrail() = RouteTrail.clear()

    /** Past drive tests kept on this phone, newest first. Local only. */
    fun driveSessions(): List<DriveSession> {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before driveSessions()" }
        return DriveHistoryStore(appContext).list()
    }

    /** The fixes saved for one past drive, in order. Local only. */
    fun driveSessionPoints(sessionId: String): List<RouteTrail.Point> {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before driveSessionPoints()" }
        return DriveHistoryStore(appContext).points(sessionId)
    }

    /** Deletes one past drive from this phone. Anything already uploaded stays on the server. */
    fun deleteDriveSession(sessionId: String) {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before deleteDriveSession()" }
        DriveHistoryStore(appContext).delete(sessionId)
    }

    /**
     * Starts continuous drive-test tracking (see DriveTestService): a fix
     * every 2 seconds while running, shown with a persistent notification.
     * The host app must already hold location permission, or the service stops
     * itself.
     *
     * [share] is the user's answer for this drive (2026-10-12). True: its
     * readings are queued for NTC; if the user was not sharing, sharing is
     * switched on for this drive and off again when it stops. False: the route
     * is kept on the phone only and nothing is queued.
     */
    fun startDriveTest(context: Context, share: Boolean) {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before startDriveTest()" }
        if (!isSupported()) return
        if (share && !isOptedIn()) {
            DriveShare.setAutoOptIn(appContext, true)
            optIn()
        }
        ContextCompat.startForegroundService(
            context,
            Intent(context, DriveTestService::class.java).putExtra(DriveTestService.EXTRA_SHARE, share),
        )
    }

    /** Id of the drive test being recorded right now, or null when none is running. */
    fun currentDriveSessionId(): String? = DriveTestService.activeSessionId

    /**
     * Where the person is now (2026-10-26): [Environment.OUTDOOR],
     * [Environment.INDOOR], [Environment.VEHICLE], or null to let the SDK
     * estimate it. Applies to every reading from now until the next call or
     * until the drive or sharing session ends.
     */
    fun setEnvironment(context: Context, value: String?) = Environment.setManual(context.applicationContext, value)

    /** The person's current choice, or null when it is estimated. */
    fun environment(context: Context): String? = Environment.manual(context.applicationContext)

    /** Ends drive-test tracking started by [startDriveTest]. Safe to call when it isn't running. */
    fun stopDriveTest(context: Context) {
        Environment.setManual(context.applicationContext, null)
        context.startService(
            Intent(context, DriveTestService::class.java).setAction(DriveTestService.ACTION_STOP),
        )
    }

    /**
     * Optional: triggers an immediate upload attempt instead of waiting for
     * [TelemetryConfig.uploadIntervalMinutes] (default 30 minutes -- and
     * WorkManager enforces a 15-minute floor on the periodic schedule
     * regardless, the same floor documented for sampling). Mainly useful
     * for a host app's own "sync now" affordance or, as here, for testing
     * against a real backend without sitting through the periodic wait.
     * Unlike the scheduled periodic upload, this does NOT wait for an
     * unmetered connection even if [TelemetryConfig.uploadOnlyOnUnmetered]
     * is true -- an explicit manual "sync now" action bypassing that is the
     * normal expectation for this kind of call (and is exactly what makes
     * it useful for testing against a real backend on an emulator, where
     * the virtual network's metered status can be unpredictable). The
     * automatic background schedule is unaffected either way.
     */
    fun uploadNow() {
        if (!isSupported()) return
        if (!isOptedIn() && !DriveShare.drainPending(appContext)) return
        WorkManager.getInstance(appContext).enqueue(OneTimeWorkRequestBuilder<UploadWorker>().build())
    }

    /**
     * Gives the SDK the host app's push token (2026-10-08), so the server can
     * ask this device for a fresh reading while it is sharing. The SDK has no
     * push library of its own; the host app gets the token and passes it in.
     * The token is sent to [TelemetryConfig.pushTokenUrl] only while opted in,
     * and is removed from the server on opt-out.
     */
    fun setPushToken(token: String?) {
        if (!::appContext.isInitialized) return
        appContext.getSharedPreferences(PUSH_PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_PUSH_TOKEN, token).apply()
        if (isOptedIn()) syncPushToken(register = true)
    }

    /**
     * Sends the stored token to the server, or removes it there. Best effort:
     * if a removal fails while offline, the server may still send a request,
     * and [answerSampleRequest] ignores it because the device is opted out.
     */
    private fun syncPushToken(register: Boolean) {
        val config = internalConfig ?: return
        val url = config.pushTokenUrl ?: return
        val token = if (register) {
            appContext.getSharedPreferences(PUSH_PREFS, Context.MODE_PRIVATE)
                .getString(KEY_PUSH_TOKEN, null) ?: return
        } else {
            ""
        }
        val deviceId = DeviceIdentity(appContext).deviceId
        val apiKey = config.apiKey
        scope.launch {
            withContext(Dispatchers.IO) {
                try {
                    val body = JSONObject().apply {
                        put("device_id", deviceId)
                        put("fcm_token", token)
                    }.toString()
                    postJson(url, body, apiKey)
                } catch (_: Exception) {
                    // Best effort. The next opt-in or token refresh sends it again.
                }
            }
        }
    }

    /**
     * Takes one reading and uploads it, in answer to a server request for
     * fresh readings from this area (2026-10-08). Does nothing unless the
     * device is opted in. Blocks for up to [ON_DEMAND_TIMEOUT_MS], so the
     * host app can call it straight from its push handler. Requests closer
     * together than [MIN_ON_DEMAND_INTERVAL_MS] are ignored.
     */
    fun answerSampleRequest() {
        if (!::appContext.isInitialized) return
        if (!isOptedIn()) return
        val now = System.currentTimeMillis()
        if (now - lastOnDemandSampleAtMs.get() < MIN_ON_DEMAND_INTERVAL_MS) return
        lastOnDemandSampleAtMs.set(now)
        runBlocking {
            val sample = withTimeoutOrNull(ON_DEMAND_TIMEOUT_MS) {
                CellSampleCollector(appContext, DeviceIdentity(appContext)).collect(triggerReason = "on_demand")
            }
            sample?.let {
                SampleQueue(appContext).append(it)
                uploadNow()
            }
        }
    }

    /**
     * Sends one Speed test card result to [TelemetryConfig.speedSamplesUrl]
     * (2026-10-07). Does nothing when that URL isn't configured, or while not
     * opted in -- this is a crowdsourced upload, same consent gate as a
     * regular sample. Since 2026-10-26 the result is held on the phone and
     * sent by [SpeedResultUploadWorker] once DT-WATCH can be reached, so a
     * test run where the server is out of reach (mobile data today) is not
     * lost. `ts` is the time of the test, not of the upload.
     */
    fun reportSpeedTest(
        pingMedianMs: Double?,
        jitterMs: Double?,
        downloadMbps: Double?,
        uploadMbps: Double?,
        networkType: String?,
        rsrpDbm: Int?,
        packetLossPct: Double? = null,
        // The connection the test used (2026-10-15): "mobile" or "wifi".
        bearer: String? = null,
    ) {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before reportSpeedTest()" }
        if (!isSupported()) return
        val config = internalConfig ?: return
        val url = config.speedSamplesUrl ?: return
        if (!isOptedIn()) return
        if (url.isEmpty()) return
        val deviceId = DeviceIdentity(appContext).deviceId
        val body = JSONObject().apply {
            put("device_id", deviceId)
            put("ts", System.currentTimeMillis())
            pingMedianMs?.let { put("ping_median_ms", it) }
            jitterMs?.let { put("jitter_ms", it) }
            packetLossPct?.let { put("packet_loss_pct", it) }
            downloadMbps?.let { put("download_mbps", it) }
            uploadMbps?.let { put("upload_mbps", it) }
            networkType?.let { put("network_type", it) }
            rsrpDbm?.let { put("rsrp_dbm", it) }
            bearer?.takeIf { it.isNotEmpty() }?.let { put("bearer", it) }
        }.toString()
        SpeedResultQueue(appContext).append(body)
        val work = OneTimeWorkRequestBuilder<SpeedResultUploadWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 60, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(appContext)
            .enqueueUniqueWork(SPEED_UPLOAD_WORK_NAME, ExistingWorkPolicy.APPEND_OR_REPLACE, work)
    }

    /**
     * Registers this device for the rescue-location lane: a separate,
     * explicit consent from the general telemetry opt-in handled by [optIn].
     * [msisdn] is stored server-side alongside this device's pseudonymous ID
     * so a rescue operator can look up a last-known location by phone
     * number -- see the backend's `SubscriberLastLocation`/`RescueLookupView`.
     *
     * The backend only starts updating that last-known location from
     * samples this device is already uploading -- so on its own, this call
     * has no effect on a device that isn't also opted into regular sampling
     * via [optIn]. This module doesn't enforce that ordering for the caller
     * (no silent auto opt-in on the host app's behalf, consistent with the
     * rest of this object's "the host app decides, we don't guess" design);
     * it's on the host app's consent UI to make that dependency clear, e.g.
     * by disabling its own rescue-registration screen until [isOptedIn].
     *
     * Requires [TelemetryConfig.rescueEnrollUrl] to be set; throws otherwise
     * rather than silently no-op-ing, since a deployment either offers this
     * feature or it's a caller bug to invoke it.
     *
     * The HTTP call itself runs on a WorkManager job ([RescueEnrollWorker])
     * rather than inline -- see that class for why. Calling this again (or
     * [optOutOfRescue]) before a prior call has synced replaces the pending
     * one; only the most recently requested consent state is ever in
     * flight.
     */
    fun enrollForRescue(msisdn: String) {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before enrollForRescue()" }
        if (!isSupported()) return
        checkNotNull(internalConfig?.rescueEnrollUrl) {
            "TelemetryConfig.rescueEnrollUrl must be set to use rescue enrollment"
        }
        enqueueRescueSync(consent = true, msisdn = msisdn)
    }

    /**
     * Withdraws rescue-location consent; the backend deletes any stored
     * last-known location for this device (see `RescueEnrollView`). Does
     * NOT affect general telemetry opt-in/out -- call [optOut] separately if
     * the host app wants both.
     */
    fun optOutOfRescue() {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before optOutOfRescue()" }
        checkNotNull(internalConfig?.rescueEnrollUrl) {
            "TelemetryConfig.rescueEnrollUrl must be set to use rescue enrollment"
        }
        enqueueRescueSync(consent = false, msisdn = null)
    }

    private fun enqueueRescueSync(consent: Boolean, msisdn: String?) {
        val data = workDataOf(
            RescueEnrollWorker.KEY_CONSENT to consent,
            RescueEnrollWorker.KEY_MSISDN to msisdn,
        )
        val request = OneTimeWorkRequestBuilder<RescueEnrollWorker>()
            .setInputData(data)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, WorkRequest.MIN_BACKOFF_MILLIS, TimeUnit.MILLISECONDS)
            .build()
        // REPLACE, not KEEP/APPEND: if the caller flips their choice again
        // before the first sync lands, only the latest requested consent
        // state should ever reach the backend.
        WorkManager.getInstance(appContext).enqueueUniqueWork(
            RESCUE_ENROLL_WORK_NAME, ExistingWorkPolicy.REPLACE, request,
        )
    }

    /**
     * Records this device's standing consent to being INCLUDED in a
     * consent-gated drive-test/coverage session -- see the backend's
     * `TelemetryDriveTestSession.require_consent` /
     * `TelemetryDriveTestConsent`. One flag, not per-session: whatever the
     * most recent call here set is what every consent-gated session's
     * samples view checks at fetch time, so accepting or withdrawing takes
     * effect on a session already in progress, not just future ones.
     *
     * Independent of both [optIn] (general telemetry collection) and
     * [enrollForRescue] (the rescue-location lane) -- this only controls
     * whether an ALREADY-collected sample is surfaced through a
     * consent-gated session's results, never whether sampling/upload
     * happens at all.
     *
     * Requires [TelemetryConfig.driveTestConsentUrl] to be set; throws
     * otherwise, same reasoning as [enrollForRescue]. Runs on a
     * WorkManager job ([DriveTestConsentWorker]), same durability/backoff
     * story as the rescue sync.
     */
    fun setDriveTestConsent(consent: Boolean) {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before setDriveTestConsent()" }
        if (!isSupported()) return
        checkNotNull(internalConfig?.driveTestConsentUrl) {
            "TelemetryConfig.driveTestConsentUrl must be set to use drive-test consent"
        }
        val data = workDataOf(DriveTestConsentWorker.KEY_CONSENT to consent)
        val request = OneTimeWorkRequestBuilder<DriveTestConsentWorker>()
            .setInputData(data)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, WorkRequest.MIN_BACKOFF_MILLIS, TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(appContext).enqueueUniqueWork(
            DRIVE_TEST_CONSENT_WORK_NAME, ExistingWorkPolicy.REPLACE, request,
        )
    }

    /**
     * Fetches the CURRENT subscriber-facing copy for drive-test
     * participation consent (backend's `DriveTestConsentConfig`, editable
     * from the Telemetry Admin page) -- a pure convenience for a host app
     * that wants centrally-editable wording instead of hardcoding its own.
     * This does NOT mean the SDK shows any UI itself; the caller is
     * expected to display [onResult]'s text (e.g. in its own consent
     * dialog) and then call [setDriveTestConsent] with the subscriber's
     * answer, same as if it had hardcoded the copy.
     *
     * Runs the network call off the main thread; [onResult] is always
     * delivered on the main thread. Unlike [enrollForRescue]/
     * [setDriveTestConsent], this does NOT throw when
     * [TelemetryConfig.driveTestConsentMessageUrl] is unset, or when the
     * fetch itself fails -- both just deliver `null`, since a failed READ
     * has an obvious safe fallback (show the host app's own hardcoded
     * copy instead) that a failed WRITE does not.
     */
    fun fetchDriveTestConsentMessage(onResult: (String?) -> Unit) {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before fetchDriveTestConsentMessage()" }
        val url = internalConfig?.driveTestConsentMessageUrl
        if (url == null) {
            onResult(null)
            return
        }
        val apiKey = internalConfig?.apiKey
        scope.launch {
            val message = DriveTestConsentApi(url, apiKey).fetchMessage()
            withContext(Dispatchers.Main) { onResult(message) }
        }
    }

    private fun scheduleBackgroundWork() {
        val config = internalConfig ?: return
        val workManager = WorkManager.getInstance(appContext)

        val samplingRequest = PeriodicWorkRequestBuilder<SamplingWorker>(
            config.effectiveSamplingIntervalMinutes, TimeUnit.MINUTES,
        ).build()
        workManager.enqueueUniquePeriodicWork(
            SAMPLING_WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, samplingRequest,
        )

        val uploadConstraints = Constraints.Builder()
            .setRequiredNetworkType(if (config.uploadOnlyOnUnmetered) NetworkType.UNMETERED else NetworkType.CONNECTED)
            .build()
        val uploadRequest = PeriodicWorkRequestBuilder<UploadWorker>(
            config.uploadIntervalMinutes, TimeUnit.MINUTES,
        ).setConstraints(uploadConstraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, WorkRequest.MIN_BACKOFF_MILLIS, TimeUnit.MILLISECONDS)
            .build()
        workManager.enqueueUniquePeriodicWork(
            UPLOAD_WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, uploadRequest,
        )
    }

    private fun startHandoverListener() {
        if (handoverListener != null) return
        val config = internalConfig ?: return
        handoverListener = HandoverListener(appContext) {
            val now = System.currentTimeMillis()
            val minGapMs = config.minHandoverSampleIntervalSeconds * 1000
            val last = lastHandoverSampleAtMs.get()
            if (now - last < minGapMs) return@HandoverListener // throttle -- see TelemetryConfig.minHandoverSampleIntervalSeconds
            if (!lastHandoverSampleAtMs.compareAndSet(last, now)) return@HandoverListener
            scope.launch {
                val identity = DeviceIdentity(appContext)
                val sample = CellSampleCollector(appContext, identity).collect(triggerReason = "handover")
                sample?.let { SampleQueue(appContext).append(it) }
            }
        }.also {
            // A revoked permission must never crash the host app at launch: the
            // listener simply stays off until the permission is granted again.
            runCatching { it.start() }
        }
    }

    /**
     * Sets how the SDK's uploads are signed (2026-10-14). The host app passes
     * a signer backed by the phone's registered key; until it returns headers,
     * uploads use the shared key. Safe to call before [init], e.g. from a
     * provider that runs at process start.
     */
    fun setRequestSigner(signer: RequestSigner?) {
        requestSigner = signer
    }

    /**
     * This SDK's device id on this phone (2026-10-14). The host app sends it
     * once, signed, so the server files signed uploads under the same identity.
     */
    fun sdkDeviceId(): String {
        check(::appContext.isInitialized) { "NetTelemetry.init() must be called before sdkDeviceId()" }
        return DeviceIdentity(appContext).deviceId
    }

    /** One small JSON POST, signed when possible. Blocking; call off the main thread. */
    private fun postJson(url: String, body: String, apiKey: String?) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val target = URL(url)
        val connection = (target.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            doOutput = true
            connectTimeout = 10_000
            readTimeout = 10_000
        }
        try {
            val signed = authorize(connection, target, "POST", bytes, apiKey)
            connection.outputStream.use { it.write(bytes) }
            noteResponse(signed, connection.responseCode)
        } finally {
            connection.disconnect()
        }
    }

    /**
     * Watches calls while sharing (2026-10-14), when [TelemetryConfig.callSamplesUrl]
     * is set. Each finished call is queued and sent once a network is available.
     */
    private fun startCallListener() {
        if (callListener != null) return
        if (internalConfig?.callSamplesUrl == null) return
        callListener = CallListener(appContext) { record ->
            CallQueue(appContext).append(record)
            val work = OneTimeWorkRequestBuilder<CallUploadWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build()
            WorkManager.getInstance(appContext)
                .enqueueUniqueWork(CALL_UPLOAD_WORK_NAME, ExistingWorkPolicy.APPEND_OR_REPLACE, work)
        }.also { runCatching { it.start() } }
    }
}

/** Set by [NetTelemetry.init]; read by the WorkManager-instantiated workers, which cannot receive constructor injection directly. */
internal var internalConfig: TelemetryConfig? = null
