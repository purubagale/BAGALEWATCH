package np.nepaltelecom.telemetry.collector

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import np.nepaltelecom.telemetry.storage.DeviceIdentity
import np.nepaltelecom.telemetry.storage.SampleQueue
import java.util.UUID

/**
 * Drive-test tracking (2026-10-04). While this service runs it asks for a
 * location fix every [FIX_INTERVAL_MS], so the route is continuous rather than
 * a scatter of one-off samples. Each fix at or under [MAX_TRACK_ACCURACY_M]
 * becomes a Sample in the upload queue, tagged with this drive's id.
 *
 * Each drive also has:
 *  - a start and a stop marker, uploaded like samples, so the server can tell
 *    exactly which fixes belong to this drive;
 *  - a copy kept on the phone (see DriveHistoryStore) for review without a
 *    network connection.
 *
 * It runs as a foreground service with a persistent notification and a Stop
 * action. It only runs when started through NetTelemetry.startDriveTest(),
 * which checks the device's opt-in first.
 */
class DriveTestService : Service() {

    private var fused: FusedLocationProviderClient? = null
    private var callback: LocationCallback? = null
    private var sessionId: String? = null
    private lateinit var history: DriveHistoryStore
    private val unsaved = ArrayList<RouteTrail.Point>()
    private val scope = CoroutineScope(Dispatchers.Default)

    /** False for a drive the user chose to keep on the phone: nothing is queued for upload. */
    private var share = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTracking()
        } else {
            share = intent?.getBooleanExtra(EXTRA_SHARE, true) ?: true
            startTracking()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopTracking()
        super.onDestroy()
    }

    private fun startTracking() {
        if (callback != null) return
        ensureChannel()
        // Must run within a few seconds of startForegroundService(), so do it
        // before anything else. The location type is required on Android 14+.
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION,
        )

        val id = UUID.randomUUID().toString()
        sessionId = id
        activeSessionId = id
        history = DriveHistoryStore(this)
        RouteTrail.clear()
        unsaved.clear()
        history.begin(id, System.currentTimeMillis())
        sendMarker("drive_start", id)

        val client = LocationServices.getFusedLocationProviderClient(this)
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, FIX_INTERVAL_MS).build()
        val cb = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { onFix(it) }
            }
        }
        fused = client
        callback = cb
        try {
            client.requestLocationUpdates(request, cb, Looper.getMainLooper())
        } catch (e: SecurityException) {
            // Location permission was revoked after the user started the test.
            stopTracking()
        }
    }

    private fun onFix(location: Location) {
        if (!location.hasAccuracy() || location.accuracy > MAX_TRACK_ACCURACY_M) return
        val id = sessionId ?: return
        val point = RouteTrail.Point(location.latitude, location.longitude, location.accuracy, location.time)
        // Save the earlier fixes before adding this one: this fix's signal is
        // read just below and is not known yet, the earlier ones' is.
        if (unsaved.size >= SAVE_EVERY) flushPoints(id)
        RouteTrail.add(point)
        unsaved.add(point)

        scope.launch {
            // Cell state is read on a background thread, off the location callback.
            val sample = CellSampleCollector(this@DriveTestService, DeviceIdentity(this@DriveTestService))
                .sampleFrom(location, triggerReason = TRIGGER_REASON, driveSessionId = id)
            sample?.let {
                point.signal = RouteTrail.Signal.from(it)
                if (share) SampleQueue(this@DriveTestService).append(it)
            }
        }
    }

    /** Saves fixes not yet written to the phone's history for this drive. */
    private fun flushPoints(id: String) {
        if (unsaved.isEmpty()) return
        val batch = unsaved.toList()
        unsaved.clear()
        scope.launch { history.addPoints(id, batch) }
    }

    /** A start or stop marker: a location-less sample that tells the server a drive began or ended. */
    private fun sendMarker(trigger: String, id: String, then: () -> Unit = {}) {
        scope.launch {
            if (share) {
                val sample = CellSampleCollector(this@DriveTestService, DeviceIdentity(this@DriveTestService))
                    .sampleFrom(null, triggerReason = trigger, driveSessionId = id)
                sample?.let { SampleQueue(this@DriveTestService).append(it) }
            }
            then()
        }
    }

    private fun stopLocationUpdates() {
        val cb = callback
        if (cb != null) fused?.removeLocationUpdates(cb)
        callback = null
    }

    private fun stopTracking() {
        stopLocationUpdates()
        val id = sessionId
        if (id != null) {
            sessionId = null
            activeSessionId = null
            flushPoints(id)
            scope.launch { history.end(id, System.currentTimeMillis()) }
            // Upload, and switch sharing back off if this drive switched it on,
            // only once the "ended" marker is in the queue.
            sendMarker("drive_stop", id) { np.nepaltelecom.telemetry.NetTelemetry.onDriveStopped() }
        }
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Drive test tracking", NotificationManager.IMPORTANCE_LOW),
            )
        }
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this,
            0,
            Intent(this, DriveTestService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Drive test running")
            .setContentText("Location is being recorded for a network drive test. Tap Stop to end it.")
            .setOngoing(true)
            .addAction(0, "Stop", stopIntent)
            .build()
    }

    companion object {
        /**
         * Id of the drive being recorded, or null when none is. The same id the
         * drive's samples carry, so a photo taken during the drive can be tied
         * to it (2026-10-12).
         */
        @Volatile
        var activeSessionId: String? = null
            private set

        /** Intent action that ends tracking. Sent by the notification's Stop button. */
        const val ACTION_STOP = "np.nepaltelecom.telemetry.DRIVE_TEST_STOP"

        /** Boolean extra on the start intent: whether this drive's readings go to NTC. */
        const val EXTRA_SHARE = "np.nepaltelecom.telemetry.DRIVE_TEST_SHARE"

        private const val CHANNEL_ID = "netplanning_drive_test"
        private const val NOTIFICATION_ID = 4201
        private const val FIX_INTERVAL_MS = 2_000L
        private const val MAX_TRACK_ACCURACY_M = 30f
        private const val SAVE_EVERY = 10

        /** Tracked fixes are uploaded as "drive" samples, so the server can tell them from other kinds. */
        private const val TRIGGER_REASON = "drive"
    }
}
